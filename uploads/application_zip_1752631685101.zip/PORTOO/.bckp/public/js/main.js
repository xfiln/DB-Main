const mobileScreenshot = document.getElementById('mobile-screenshot');
const desktopScreenshot = document.getElementById('desktop-screenshot');

// Fetch screenshots for OMG Uploader
fetch('/api/screenshot?url=https://cdn.uploader.dreamliner.my.id&device=phone')
  .then(response => response.json())
  .then(data => {
    mobileScreenshot.src = data.result; // Set the image URL
  })
  .catch(err => console.error('Error fetching mobile screenshot:', err));

fetch('/api/screenshot?url=https://cdn.uploader.dreamliner.my.id&device=desktop')
  .then(response => response.json())
  .then(data => {
    desktopScreenshot.src = data.result; // Set the image URL
  })
  .catch(err => console.error('Error fetching desktop screenshot:', err));

// CONTACT FORM
const form = document.getElementById("contactForm");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const message = document.getElementById("message").value;

  if (!name || !email || !message) {
    Swal.fire("Oops!", "All fields are required.", "error");
    return;
  }

  try {
    const response = await fetch("/submit-contact", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name, email, message }),
    });

    const data = await response.json();

    if (data.success) {
      Swal.fire("Success!", "Your message has been sent!", "success");
      form.reset();
    } else {
      Swal.fire("Error", "There was an error sending your message. Please try again.", "error");
    }
  } catch (error) {
    Swal.fire("Error", "An error occurred. Please try again later.", "error");
  }
});