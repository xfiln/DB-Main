const express = require("express");
const fetch = require("node-fetch");
const path = require("path");
const { apiKey } = require("./config");

const app = express();
const port = 2390;

// Middleware untuk EJS dan file statis
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// CORS Middleware (optional, if needed)
const cors = require('cors');
app.use(cors());

// Endpoint untuk halaman utama (index)
app.get("/", (req, res) => { res.render("index"); });

// Endpoint untuk halaman project app.get("/project", (req, res) => { res.render("project"); });

// Endpoint untuk screenshot (updated to /api/screenshot)
app.get("/api/screenshot", async (req, res) => {
  const { url, device } = req.query;

  if (!url || !device) {
    return res.status(400).json({ error: "Parameter 'url' dan 'device' diperlukan." });
  }

  try {
    // Fetch ke API eksternal
    const response = await fetch(
      `https://api.betabotz.eu.org/api/tools/ssweb?url=${encodeURIComponent(url)}&device=${device}&apikey=${apiKey}`
    );

    // Check if the response is OK
    if (!response.ok) {
      const errorMessage = await response.text();
      console.error("Error from API:", errorMessage);
      return res.status(response.status).json({ success: false, message: errorMessage });
    }

    const data = await response.json();

    if (data.result) {
      res.json({ success: true, result: data.result });
    } else {
      res.status(500).json({ success: false, message: "Gagal mengambil screenshot." });
    }
  } catch (error) {
    console.error("Error fetching screenshot:", error);
    res.status(500).json({ success: false, message: "Terjadi kesalahan server." });
  }
});

// Endpoint untuk halaman kontak
app.get("/contact", (req, res) => {
  res.render("contact");
});

// Endpoint untuk menangani pengiriman kontak
app.post("/submit-contact", async (req, res) => {
  const { name, email, message } = req.body;

  // Simulasikan pengiriman pesan atau menyimpannya ke database
  console.log("New contact message received:");
  console.log("Name:", name);
  console.log("Email:", email);
  console.log("Message:", message);

  // Jika pengiriman berhasil, beri respons sukses
  res.json({ success: true });
});

// Menjalankan server
app.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
});