const express = require("express");
const nodemailer = require("nodemailer");
const axios = require("axios");
const fs = require("fs");
const morgan = require("morgan");
const app = express();
const port = 2390;

// Middleware
app.use(express.json());
app.use(express.static("public"));
app.use(morgan("dev"));

// Path untuk file log
const publicLogFile = "./logs/public.log";
const serverLogFile = "./logs/server.log";

// Helper untuk mencatat log
const logActivity = (message, detailed = false) => {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] ${message}\n`;

  // Log untuk publik
  fs.appendFileSync(publicLogFile, `[${timestamp}] ${message.split(" - ")[0]}\n`);

  // Log untuk server (lebih detail)
  if (detailed) {
    fs.appendFileSync(serverLogFile, logMessage);
  }
};

// Route untuk screenshot
app.get("/screenshot", async (req, res) => {
  const apiKey = "paullch"; // Ganti dengan API key
  const screenshotURL = `https://api.betabotz.eu.org/api/tools/ssweb?url=https://cdn.uploader.dreamliner.my.id&device=desktop&apikey=${apiKey}`;

  try {
    const response = await axios.get(screenshotURL, { responseType: "arraybuffer" });
    res.set("Content-Type", "image/png");
    /*logActivity("Screenshot diambil - URL: cdn.uploader.dreamliner.my.id", true);*/
    res.send(response.data);
  } catch (error) {
    console.error(error);
    /*logActivity("Gagal mengambil screenshot - Error terjadi", true);*/
    res.status(500).send("Gagal mengambil screenshot.");
  }
});

// Route untuk mengirim email
app.post("/send-email", async (req, res) => {
  const { email } = req.body;
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: "your-email@gmail.com", // Ganti dengan email Anda
      pass: "your-email-password", // Ganti dengan password email Anda
    },
  });

  try {
   await transporter.sendMail({
      from: "your-email@gmail.com",
      to: email,
      subject: "Halo dari Portofolio JKT48 🌸",
      text: "Terima kasih telah menghubungi saya!",
   });
   logActivity(`Email dikirim ke ${email}`, true);
   res.json({ success: true });
} catch (error) {
   console.error(error);
   logActivity(`Gagal mengirim email ke ${email}`, true);
   res.json({ success: false });
}
});

//Endpoint For Message To Telegram
app.post("/send-message", async (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
  return res.status(400).send("Nama, email, dan pesan diperlukan");
  }
  
  const chatId = "-1002383256798"; //idChat
  const token = "7867708084:AAG2VusedaxLPd2mCkwpPMEk39Nr7W2Pkrw"; //token Bot
  const telegramUrl = `https://api.telegram.org/bot${token}/sendMessage`; //Telegram Url
  
  const text = `<b>Pesan Baru Dari Portofolio</b>\n\n` +
  `<b>Sender:</b> ${name}\n` +
  `<b>Email:</b> ${email}\n` +
  `<b>Pesan:</b> ${message}`;
  try {
    const response = await fetch(telegramUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML"}),
    });
    if (response.ok) {
   logActivity(`pesan berhasil dikirim ke ${chatId}`, true);
   return res.status(200).json({ success: true, message: "Pesan Berhasil Terkirim YGY." });
} else {
   logActivity(`Gagal mengirim pesan ke ${chatId}`, true);
   return res.status(500).json({ success: false, message: "Gagal Mengirim Pesan Coyy" });
}
  } catch (error) {
    console.error(error);
    res.status(500).send("Alamak Ada Yang Kesalahan Pas Ngirim Pesan Bjirr, Coba Lagi Ntar");
    logActivity(`Ada Kesalahan Saat mengirim pesan ke ${chatId}`, true);
    res.json({ success: false });
  }
});

// Route untuk menampilkan log publik
app.get("/api/logs", (req, res) => {
  try {
    const logs = fs.readFileSync(publicLogFile, "utf-8");
    res.set("Content-Type", "text/plain");
    res.send(logs);
  } catch (error) {
    console.error("Gagal membaca log publik:", error);
    res.status(500).send("Gagal membaca log.");
  }
});

// Menjalankan server
app.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
  logActivity("Server dimulai", true);
});