document.getElementById("sendEmail").addEventListener("click", function() {
      Swal.fire({
        title: "Masukkan Email",
        input: "email",
        inputLabel: "Email Anda",
        inputPlaceholder: "Masukkan email untuk menghubungi Anda",
        showCancelButton: true,
        confirmButtonText: "Kirim",
      }).then((result) => {
        if (result.isConfirmed && result.value) {
          // Mengirim request POST ke endpoint /send-email
          fetch("/send-email", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ email: result.value }),
          })
          .then((response) => response.json())
          .then((data) => {
            if (data.success) {
              Swal.fire("Email berhasil dikirim!", "", "success");
            } else {
              Swal.fire("Gagal mengirim email!", "", "error");
            }
          })
          .catch(() => {
            Swal.fire("Gagal mengirim email!", "", "error");
          });
        }
      });
    });
    
    // Mengirim pesan ke telegram
    document.getElementById("sendMessage").addEventListener("click", function() {
  Swal.fire({
    title: "Kirim Pesan",
    html:
      '<input id="swal-input1" class="swal2-input" placeholder="Nama Anda">' +
      '<input id="swal-input2" type="email" class="swal2-input" placeholder="Email Anda">' +
      '<textarea id="swal-input3" class="swal2-textarea" placeholder="Pesan Anda"></textarea>',
    focusConfirm: false,
    showCancelButton: true,
    confirmButtonText: "Kirim",
    preConfirm: () => {
      const name = document.getElementById("swal-input1").value;
      const email = document.getElementById("swal-input2").value;
      const message = document.getElementById("swal-input3").value;

      if (!name || !email || !message) {
        Swal.showValidationMessage("Semua field wajib diisi!");
        return false;
      }
      return { name, email, message };
    }
  }).then((result) => {
    if (result.isConfirmed) {
      const { name, email, message } = result.value;
      fetch("/send-message", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, email, message }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            Swal.fire("Pesan berhasil dikirim!", "", "success");
          } else {
            Swal.fire("Gagal mengirim pesan!", "", "error");
          }
        })
        .catch(() => {
          Swal.fire("Terjadi kesalahan pada server!", "", "error");
        });
    }
  });
});

fetch('/api/logs')
      .then(response => response.text())
      .then(data => {
        document.getElementById('logContainer').innerText = data;
      })
      .catch(error => {
        console.error('Error fetching logs:', error);
      });